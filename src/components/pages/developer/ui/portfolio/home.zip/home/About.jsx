import React from "react";
import { ImgUrl } from "../../helpers/functions-general";
import { Link } from "react-router-dom";
import { FaFacebook, FaLinkedin, FaTwitter } from "react-icons/fa";
import { GrMail } from "react-icons/gr";
import { PiDownloadSimpleFill } from "react-icons/pi";

const About = () => {
	return (
		<>
			<section
				id='about'
				className='about md:px-5 pt-[10rem] h-auto md:h-screen '>
				<div className='container'>
					<div className='about__wrapper  md:flex md:flex-col md:gap-5 md:justify-around'>
						<h2 className='about__header mb-10 text-7xl text-right opacity-70'>
							About
						</h2>
						<div className='flex flex-col md:flex-row md:gap-10  justify-around w-full'>
							<div className='about__img md:w-1/2 relative mb-5 md:mb-0'>
								<img
									className='object-cover  z-999 border-gradient-br-blue-green-gray-900 gradient-border-3 size-[500px] bg-wavyBG rounded-xl'
									src={`${ImgUrl}/facebook.jpg`}
									alt=''
								/>
								<div className='-translate-y-[35rem] md:-translate-y-[25rem] absolute'>
									<img
										className='md:animate-planetmd animate-planet z-99 '
										src={`${ImgUrl}/planet-svgrepo-com.svg`}
										alt=''
									/>
								</div>
							</div>

							<div className='about__text flex flex-col gap-5 w-full md:text-left text-justify md:px-5 md:w-1/2 '>
								<h3 className='text-center md:text-left'>
									Lorem ipsum dolor sit amet.
								</h3>
								<p>
									Lorem ipsum dolor sit amet consectetur adipisicing elit.
									Repellendus est aspernatur libero. Debitis explicabo atque
									corporis? Eaque itaque libero laudantium ipsam ad in
									doloremque dolore autem distinctio, minus recusandae suscipit
									ab dolores deleniti placeat cumque totam et ipsa architecto?
									Incidunt, omnis? Tenetur autem quisquam iste repudiandae,
									maiores consectetur blanditiis accusantium.
								</p>
								<ul className='socialicons flex flex-col md:flex-row gap-5 justify-around md:items-center  md:w-[66%] text-2xl'>
									<li>
										<button>
											<Link to='https://www.facebook.com/ArrisSaavedra'>
												<FaFacebook />
												<p>/ArrisSaavedra</p>
											</Link>
										</button>
									</li>
									<li>
										<button>
											<Link to='#'>
												<FaTwitter />
												<p>@Dokusha</p>
											</Link>
										</button>
									</li>
									<li>
										<button>
											<Link to='https://www.linkedin.com/in/arris-jeff-saavedra-a6787a260/'>
												<FaLinkedin />
												<p>/ArrisSaavedra</p>
											</Link>
										</button>
									</li>
									<li>
										<button>
											<Link to='mailto:saavedraarrisss@gmail.com'>
												<GrMail />
												<p>/SaavedraArrisss@gmail.com</p>
											</Link>
										</button>
									</li>
								</ul>
								<button className='w-[66%] btn btn-accent-cv rounded-br-xl  flex justify-center md:self-start self-center  text-center rounded-bl-xl'>
									<Link className='flex flex-row items-center gap-5'>
										Download CV <PiDownloadSimpleFill className='text-2xl' />
									</Link>
								</button>
							</div>
						</div>
					</div>
				</div>
			</section>
		</>
	);
};

export default About;
