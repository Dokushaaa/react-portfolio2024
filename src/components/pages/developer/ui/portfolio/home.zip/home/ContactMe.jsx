import React from "react";

const ContactMe = () => {
	return (
		<>
			<section
				id='contacts'
				className='CTA h-auto w-full pt-[10rem]'>
				<div className='container'>
					<div className='contact__wrapper'>
						<h2 className='text-right text-6xl py-5 opacity-60'>Contacts</h2>
						<div className='flex flex-col gap-5'></div>
					</div>
				</div>
			</section>
		</>
	);
};

export default ContactMe;
