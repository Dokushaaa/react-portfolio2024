import React from "react";
import Header from "../../partials/header/Header";
import { baseImgUrl, ImgUrl } from "../../helpers/functions-general";
import { Link } from "react-router-dom";
import {
	FaBook,
	FaFacebook,
	FaInstagram,
	FaLinkedin,
	FaReact,
	FaTwitter,
} from "react-icons/fa";
import About from "./About";
import Skills from "./Skills";
import ProjectSlider from "./ProjectsSlider";
import ContactMe from "./ContactMe";

const Home = () => {
	return (
		<>
			<Header />

			<section
				id='home'
				className='home max-h-[54rem] h-screen w-full py-[10rem]'>
				<div className='homeBanner z-[99]'>
					<div className='container'>
						<h2 className='home__header mb-10 text-7xl opacity-70'>Home</h2>
						<div className='homeBanner__wrapper w-full flex md:flex-row  flex-col gap-2 md:justify-evenly md:gap-10 items-center md:py-14'>
							<div className='homeBanner__img rounded-br-lg  rounded-tl-lg bg-wavyBG md:w-[32.5rem] w-[22.5rem] md:h-auto h-[22.5rem] py-2 h-auto flex items-right md:mb-0 mb-5 rounded-rb-md'>
								<img
									className='w-auto rounded-br-lg shadow-xl md:scale-90 scale-95 hover:scale-100  hover:animate-spin transition-all  md:animate-loading2md duration-500  animate-loading2sm'
									src={`${baseImgUrl}/reactjs-svgrepo-com.svg`}
									alt=''
								/>
							</div>
							<div className='homeBanner__text text-center md:text-justify px-5 md:px-0'>
								<h1 className='uppercase md:text-5xl lg:text-7xl xl:text-9xl'>
									Saavedra, Arris-Jeff S
								</h1>
								<div className='block-header'>
									<h2 className='md:text-4xl pl-[10rem]'>
										Front-End Developer
									</h2>
								</div>
								<div className='homeBanner__textBtn  w-[25rem] flex gap-5 justify-center md:justify-start'>
									<button className='btn btn-secondary flex flex-row items-center text-primary w-1/2  gap-2'>
										{" "}
										<FaBook />
										<Link className='text-center'>Get to know me more?</Link>
									</button>
									<button className='hidden md:flex btn btn-secondary flex-row items-center text-primary w-auto'>
										<Link className='text-center'>Coding</Link> <FaReact />
									</button>
								</div>
							</div>
						</div>
						<div className='home__text text-center w-full py-10 md:py-0 md:text-2xl'>
							<p className='text-center md:text-left'>
								an upcoming graduate of STI College San Pablo City. Specializing
								in project management
							</p>
							<p className='text-center md:text-left'>
								I also am training to be able to be a full-stack developer in
								the near future
							</p>
						</div>
					</div>
				</div>
			</section>

			<About />
			<Skills />
			<ContactMe />

			{/* <Footer/> */}
		</>
	);
};

export default Home;
