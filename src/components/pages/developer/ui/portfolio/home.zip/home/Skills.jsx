import React from 'react'
import { skillData } from './skillsData';
import { baseImgUrl } from '../../helpers/functions-general';
import Skillset from './Skillset';
import ProjectsSlider from './ProjectsSlider';
import SkillCertifications from './SkillCertifications';
import ExperienceBG from './ExperienceBG';

const Skills = () => {
    const [menuTab, setMenuTab] = React.useState('Programming Languages');
    const [isModalShow, setModalShow] = React.useState(false);
    
    const handleChangeMenu = (menu) => {
        setMenuTab(menu);
    }
 return (
   <>
   <section id="skills" className="skills h-auto w-full pt-[10rem]">
    <div className="container">
    <div className="skills__wrapper">
    <h2 className='text-left text-6xl py-5 opacity-60'>Experience: {menuTab}</h2>
        <div className="skills__menu  md:flex md:flex-row ">
        <div className='aside md:h-screen w-full md:w-1/4'>
        <ul className="skills__navbar text-3xl items-center flex flex-col gap-5 md:w-full">
        <li><button className={`font-bold ${menuTab === "Programming Languages" ? "active" : "font-medium"}`} onClick={() => handleChangeMenu("Programming Languages")}>Programming Languages</button></li>
        <li><button className={`font-bold ${menuTab === "Coding Projects" ? "active" : "font-medium"}`} onClick={() => handleChangeMenu("Coding Projects")}>Projects</button></li>
        <li><button className={`font-bold ${menuTab === "Certifications" ? "active" : "font-medium"}`} onClick={() => handleChangeMenu("Certifications")}>Certifications</button></li>
        <li><button className={`font-bold ${menuTab === "Background" ? "active" : "font-medium"}`} onClick={() => handleChangeMenu("Background")}>Background</button></li>

        </ul>
    </div>
    <div className='main md:h-screen w-full md:pl-10 pb-10 md:w-3/4'>
              {menuTab === "Programming Languages" && <Skillset setModalShow={setModalShow}/>}
              {menuTab === "Coding Projects" && <ProjectsSlider setModalShow={setModalShow}/>}
              {menuTab === "Certifications" && <SkillCertifications setModalShow={setModalShow}/>}
              {menuTab === "Background" && <ExperienceBG setModalShow={setModalShow}/>}
              
        </div>



        
        </div>
    </div>
    </div>
   </section>
   </>
  )
}

export default Skills