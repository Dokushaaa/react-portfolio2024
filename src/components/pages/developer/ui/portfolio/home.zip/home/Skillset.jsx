import React from "react";
import { skillData } from "./skillsData";
import { baseImgUrl } from "../../helpers/functions-general";

const Skillset = () => {
	return (
		<>
			<div className="skill__container  flex flex-col items-center md:grid md:grid-cols-4 md:gap-5 md:translate-x-[12.5%]">
				{skillData.map((item, key) => (
					<div
						key={key}
						className="skill__card bg-primary m-2 rounded-br-xl rounded-tl-xl w-auto h-[calc(100%+10px)] md:h-1/2 size-[50rem] md:h-[calc(100%-10px)]  p-5 flex md:flex-col flex-row items-center gap-5 md:text-left text-center justify-center">
						<img
							className="pb-5 md:size-full size-1/2"
							src={`${baseImgUrl}/${item.img}`}
							alt=""
						/>
						<h2>{item.title}</h2>
					</div>
				))}
			</div>
		</>
	);
};

export default Skillset;
