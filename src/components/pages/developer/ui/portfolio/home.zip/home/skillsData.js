export const skillData = [
	{
		img: "../../../../public/img/c-sharp-svgrepo-com.svg",
		title: "C Sharp",
	},
	{
		img: "../../../../public/img/java-svgrepo-com.svg",
		title: "Java",
	},
	{
		img: "../../../../public/img/oracle-svgrepo-com.svg",
		title: "Oracle",
	},
	{
		img: "../../../../public/img/html-5-svgrepo-com.svg",
		title: "HTML or HTML5",
	},
	{
		img: "../../../../public/img/css-3-svgrepo-com.svg",
		title: "CSS",
	},
	{
		img: "../../../../public/img/js-svgrepo-com.svg",
		title: "JavaScript",
	},
	{
		img: "../../../../public/img/sass-svgrepo-com.svg",
		title: "SASS",
	},
	{
		img: "../../../../public/img/tailwind-svgrepo-com.svg",
		title: "Tailwind CSS",
	},
	{
		img: "../../../../public/img/reactjs-svgrepo-com.svg",
		title: "React.JS (Non-Native)",
	},
	{
		img: "../../../../public/img/python-svgrepo-com.svg",
		title: "Python",
	},
];
