import React from 'react'

const ExperienceBG = ({setModalShow}) => {
  return (
    <div>ExperienceBG</div>
  )
}

export default ExperienceBG