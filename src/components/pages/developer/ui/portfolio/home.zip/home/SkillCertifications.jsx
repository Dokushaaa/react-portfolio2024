import React from "react";
import { FaChevronDown } from "react-icons/fa";

const SkillCertifications = ({ setModalShow }) => {
	const [showCerts, setShowCerts] = React.useState(false);
	const handleShowProject = () => {
		setShowCerts(!showCerts);
	};
	const handleShowModal = (item) => {
		setModalShow(true);
	};
	return (
		<>
			<button onClick={handleShowProject}>
				<div className="flex flex-col justify-center py-5 w-[24rem] md:w-[75rem] ">
					<div className="container">
						<div
							className={`skill__dropdown bg-header flex flex-row items-center  py-2  px-5 justify-between rounded-tl-xl rounded-br-xl  ${
								showCerts
									? "rounded-br-none transition-all duration-500 "
									: "transition-all duration-500 rounded-br-xl border-b-2 border-accent"
							}`}>
							<h2 className="py-2">Project 1</h2>
							<FaChevronDown className="text-2xl" />
						</div>
						<div
							className={`bg-header w-full text-justify ${
								showCerts
									? "items-center flex flex-col min-h-[40rem]  transition-all duration-500 rounded-br-xl"
									: " hidden min-h-[5rem] transition-all duration-500 "
							}`}>
							<div className="container">
								<img
									className="py-4"
									src="https://via.placeholder.com/700x400"
									alt=""
								/>
								<h3>
									Lorem ipsum dolor sit amet consectetur, adipisicing elit.
									Possimus numquam quibusdam dolorem aspernatur aliquam cum
									illum, fuga qui recusandae inventore dignissimos, laudantium
									quisquam facilis beatae dolores eius! Laudantium eos hic
									exercitationem, vero dolores ipsam cupiditate vel dolorum
									officia iste distinctio mollitia molestiae officiis est
									temporibus corrupti voluptas sit magni eveniet.
								</h3>
							</div>
						</div>
					</div>
				</div>
			</button>
		</>
	);
};

export default SkillCertifications;
