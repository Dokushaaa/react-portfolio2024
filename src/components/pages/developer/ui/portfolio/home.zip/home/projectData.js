export const projectsDescription = [
    {
        img:"https://via.placeholder.com/200x200",
        title:"Hello"
        
    },
    {
        img:"https://via.placeholder.com/200x200",
        title:"Hello"
        
    },
    {
        img:"https://via.placeholder.com/200x200",
        title:"Hello"
        
    },

]